#!/usr/bin/ruby

require "vrlib"

# from require_all gem:
require_rel 'src/'


MyClass.new.show_glade()
=begin
This is the algorithm for project 2
four features: number, symbols, shadings, colors
corresponding to the four elements in card
each features has three possible situations:0, 1, 2
=end
class Fitset
	def initialize(first, second, third)
		@first_fit = first
		@second_fit = second
		@third_fit = third
	end
	
end


#this method check if the number feature of three cards meet the requirement 
def numberfillter (cards, i ,j ,k)
	fit = (cards[i][0]== cards[j][0])&&(cards[i][0]==cards[k][0])&&(cards[j][0]== cards[k][0])||(cards[i][0]!= cards[j][0])&&(cards[i][0]!=cards[k][0])&&(cards[j][0]!= cards[k][0])
	return fit
end

#this method check if the symbol feature of three cards meet the requirement
def symbolfillter cards, i, j, k
  fit = (cards[i][1]== cards[j][1])&&(cards[i][1]==cards[k][1])&&(cards[j][1]== cards[k][1])||(cards[i][1]!= cards[j][1])&&(cards[i][1]!=cards[k][1])&&(cards[j][1]!= cards[k][1])
        return fit

end

#this method check if the shading feature of three cards meet the requirement
def shadingfillter( cards ,i, j, k)
  fit = (cards[i][2]== cards[j][2])&&(cards[i][2]==cards[k][2])&&(cards[j][2]== cards[k][2])||(cards[i][2]!= cards[j][2])&&(cards[i][2]!=cards[k][2])&&(cards[j][2]!= cards[k][2])
        return fit
end
#this method check if the color feature of three cards meet the requirement
def colorfillter (cards, i, j, k)
  fit = (cards[i][3]== cards[j][3])&&(cards[i][3]==cards[k][3])&&(cards[j][3]== cards[k][3])||(cards[i][3]!= cards[j][3])&&(cards[i][3]!=cards[k][3])&&(cards[j][3]!= cards[k][3])
        return fit

end

#this method find all the sets in 12 cards that meet the requirement
def findSet(cards)
	allgoodSet = []
	i, j, k , m= 0, 0, 0, 0
	while i<cards.size do
		j = i+1
		while j <cards.size do
		       k = j+1
		       while k <cards.size do
				colorfillter cards, i, j, k

				if((numberfillter cards, i, j, k)&&(symbolfillter cards, i, j, k)&&(shadingfillter cards, i, j ,k)&&(colorfillter cards, i, j, k))
					oneSet= Fitset.new(i, j, k)
					puts "Fit sets are "+i.to_s+" "+ j.to_s+" "+ k.to_s
					allgoodSet.push oneSet
					m= m+1					
				end		

				k=k+1
			end
			j = j+1
	 	end		
		i=i+1
	end

return allgoodSet, m
end

#this method print out all 12 cards 
def printCards( cards)
	i = 0
  x = 1
  y = 1
  symbol[] = ['Di', 'Sq', 'Ov']
  color[] = ['Red', 'Green', 'Purple']
  shade[] = ['Blank', 'Line', 'Fill']
	while i < cards.size do
		String fullName = cards[i][0].to_s+ symbol[cards[i][1]] + color[cards[i][3]] + shade[cards[i][2]] + '.png'
    show_image(x, y, fullName)
    x = x + 1
    if x == 3
      x = 1
      y = y + 1
    end
	i = i + 1
	end
			
end	

#this method check if the input three cards from the user meet the requirements
def getCheckInput (cards,i,j, k)	
	result = true
	if((numberfillter cards, i, j, k)&&(symbolfillter cards, i, j, k)&&(shadingfillter cards, i, j ,k)&&(colorfillter cards, i, j, k))
		result = true
	else
		result = false
	end
	puts result
	return result
end
#this method change the number in range [0, 80] into four numbers(0, 1, 2)
def changeNumber allCards
	i =0
	while i<81 do
		element = allCards[i]
		oneCard = []
		oneCard.push element%3
		oneCard.push (element/3)%3
		oneCard.push (element/9)%3
		oneCard.push (element/27)%3
		allCards[i] = oneCard
		i = i+1	
	end	
	return allCards
end

#this method update the cards at the index i, j, k
def updateCardSet cards, allCards, index, i, j, k
	cards[i] = allCards[index]
	index = index +1
	cards[j] = allCards[index]
	index =index +1
	cards[k] = allCards[index]
	index = index +1
	fitSet = []
	fitSet, fitSize=findSet cards
	puts "There will be "+fitSize.to_s+" sets cards meets the requirement\n"
	while fitSize == 0 do
        	index = index+3
     	   	cards.push  allCards[index-3], allCards[index-2], allCards[index-1]
        	fitSet, fitSize=findSet cards
		puts fitSize
	end
	return cards, index
end	

#this method start the game
def playGame cards, allCards, index
	
	num = 0
	while index < 81 do
		printCards cards
		puts "Enter three index of three set that is fitted: "
		i =gets.chomp.to_i
        	j = gets.chomp.to_i
	        k =gets.chomp.to_i
		oneSet = Array.new(3)
		if (i==j)||(i==k)||(j==k)||!(i>=0&&i<=11)||!(j>=0&&j<=11)||!(k>=0&&k<=11)
			puts "Invalid inputs"
		elsif getCheckInput cards, i, j, k
			oneSet=[i,j,k]
			oneSet.sort
			puts "your answer is right"
			
			cards, index = updateCardSet cards, allCards, index, i, j, k
			num = num + 1
			puts "You have find "+num.to_s+" fitted sets"			
			
		else
			puts "incorrect Set"
		end
	end	
end
allCards = Range.new(0,80).to_a.shuffle
allCards = changeNumber allCards
index = 12
cards = allCards[0, index]
fitSet = []
fitSet, fitSize=findSet cards

puts "There will be "+fitSize.to_s+" sets cards meets the requirement\n"
while fitSize == 0 do
	index = index+3
	cards = allCards[0,index]
	fitSet, fitSize=findSet cards
end

#start the game
playGame cards, allCards, index
