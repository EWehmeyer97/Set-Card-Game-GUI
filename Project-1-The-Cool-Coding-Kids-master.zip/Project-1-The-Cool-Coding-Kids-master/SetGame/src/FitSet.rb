class FitSet
  
	def initialize(first, second, third)
		@first_fit = first
		@second_fit = second
		@third_fit = third
	end

end
