
class MyClass
 
  include GladeGUI

def initialize
  @path = File.dirname(__FILE__) + "/setCards/"
end

def show_image(x, y, fullName)
  @builder['r'+x.to_s+'c'+y.to_s].file = @path + fullName
  
end

end	
