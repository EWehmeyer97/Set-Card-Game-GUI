
class MyClass #(change name)
 
  include GladeGUI


# $currentSet stores the cards show on the board
# $fittedSet stores the sets of cards that meet the require
# $allCards stores all 81 cards
# $clicked stores the index of checkButton that is been selected
# $Index stores the cards that used
# $score stores the total score user get
# $setsFound stores the total number of sets the player has found
# $attempts stores how many tries/attempts the user plays
    $currentSet = []
    $fittedSet = []
    $allCards = []
    $clicked = [10000]
    $Index = 12
    $score =0
    $setsFound = 0
    $attempts = 0

#this method set the default picture to blank
  def before_show 
    @builder["window1"].title = "Game of Set"
    @path = File.dirname(__FILE__)+"/img1/"
    defaultpic = "blank.png"
    @builder["pic1"].file = @path +defaultpic
    @builder["pic2"].file = @path +defaultpic
    @builder["pic3"].file = @path +defaultpic
    @builder["pic4"].file = @path +defaultpic
    @builder["pic5"].file = @path +defaultpic
    @builder["pic6"].file = @path +defaultpic
    @builder["pic7"].file = @path +defaultpic
    @builder["pic8"].file = @path +defaultpic
    @builder["pic9"].file = @path +defaultpic
    @builder["pic10"].file = @path +defaultpic
    @builder["pic11"].file = @path +defaultpic
    @builder["pic12"].file = @path +defaultpic
    @builder["pic13"].file = @path +defaultpic
    @builder["pic14"].file = @path +defaultpic
    @builder["pic15"].file = @path +defaultpic
end  



#this method check if the number feature of three cards meet the requirement 
def numberfillter (cards, i ,j ,k)
	fit = (cards[i][0]== cards[j][0])&&(cards[i][0]==cards[k][0])&&(cards[j][0]== cards[k][0])||(cards[i][0]!= cards[j][0])&&(cards[i][0]!=cards[k][0])&&(cards[j][0]!= cards[k][0])
	return fit
end
#this method check if the symbol feature of three cards meet the requirement
def symbolfillter cards, i, j, k
  fit = (cards[i][1]== cards[j][1])&&(cards[i][1]==cards[k][1])&&(cards[j][1]== cards[k][1])||(cards[i][1]!= cards[j][1])&&(cards[i][1]!=cards[k][1])&&(cards[j][1]!= cards[k][1])
        return fit
end

#this method check if the shading feature of three cards meet the requirement
def shadingfillter( cards ,i, j, k)
  fit = (cards[i][3]== cards[j][3])&&(cards[i][3]==cards[k][3])&&(cards[j][3]== cards[k][3])||(cards[i][3]!= cards[j][3])&&(cards[i][3]!=cards[k][3])&&(cards[j][3]!= cards[k][3])
        return fit
end
#this method check if the color feature of three cards meet the requirement
def colorfillter (cards, i, j, k)
  fit = (cards[i][6]== cards[j][6])&&(cards[i][6]==cards[k][6])&&(cards[j][6]== cards[k][6])||(cards[i][6]!= cards[j][6])&&(cards[i][6]!=cards[k][6])&&(cards[j][6]!= cards[k][6])
        return fit
end

#this method find all the sets in 12 cards that meet the requirement
def findSet(cards)
	allgoodSet = []
	i, j, k , m= 0, 0, 0, 0
	while i<cards.size do
		j = i+1
		while j <cards.size do
		       k = j+1
		       while k <cards.size do
				colorfillter cards, i, j, k
				if((numberfillter cards, i, j, k)&&(symbolfillter cards, i, j, k)&&(shadingfillter cards, i, j ,k)&&(colorfillter cards, i, j, k))
					oneSet = [i+1, j+1, k+1]
          oneSet.sort
					allgoodSet.push oneSet
					m= m+1					
				end		
				k=k+1
			end
			j = j+1
	 	end		
		i=i+1
	end
  return allgoodSet, m
end
#this method change the number in allCards to a string
def changeNumber allCards
	i =0
  symbol = ['Di', 'Sq', 'Ov']
  color = ['Red', 'Gre', 'Pur']
  shade = ['Blan', 'Line', 'Fill']
	while i<81 do
		element = allCards[i]
		oneCard = ""
		oneCard =(1+element%3).to_s+ symbol[(element/3)%3].to_s+ color[(element/9)%3].to_s+ shade[(element/27)%3].to_s+".png"
		allCards[i] = oneCard
		i = i+1	
	end	
	return allCards
end

# this method stores the function for set button
# it checks if the selected set meet the requirement and print the message
# if the requirement meet, the three cards selected will be changed
# after these operation all the checkbutton will be resetted
# if all 81 cards used, this method will start the game again atomatically
def button1__clicked(*args)
    $clicked.sort
  if($clicked.size != 4)then
    @builder["entry1"].text = "Must be three cards"
  else
    selected = $clicked[1,4]
    selected.sort!
    $attempts += 1
    if($fittedSet.include? selected) then
      @builder["entry1"].text = "Correct set"
      $score = $score +3
      @builder["entry2"].text = "Score: "+$score.to_s
      $Index = $Index + 3
      $setsFound += 1
      if $Index <= 80 then
          $currentSet[selected[0]-1] = $allCards[$Index-3] #Something is not happening here!
          $currentSet[selected[1]-1] = $allCards[$Index-2]
          $currentSet[selected[2]-1] = $allCards[$Index-1]
          cards = $currentSet          
          $fittedSet, m = findSet(cards)
          while m ==0 do
            $Index = $Index +3
            cards.push $allCards[$Index-3]
            cards.push $allCards[$Index-2]
            cards.push $allCards[$Index-1]
            $fittedSet, m = findSet(cards)
          end
          $currentSet = cards
          i=1          
          while i <= 15 do
           picName = "pic"+ i.to_s
           if i<=cards.size then 
                @builder[picName].file = @path + cards[i-1].to_s
           else   
                @builder[picName].file = @path + "blank.png"
           end           
          i=i+1
          end
      else
          button3__clicked()
      end
    else
      @builder["entry1"].text = "Incorrect set"
      @builder["entry2"].text = "Score: "+$score.to_s
    end
  end
    @builder["accuracy"].text = ($setsFound.to_f/$attempts.to_f*100).to_s + "%"
  j = 1
  while j <= 15 do
    button = "checkButton"+j.to_s
    @builder[button].active = false
    j = j+1
  end
  $clicked =[10000]
end
#this method defines the function for hint, it will tell user a start card for possible set
def button2__clicked(*args)
  if  $fittedSet.empty? then
    @builder["entry1"].text = "Start game first"
  else
    $score -= 1
    checkButton = "checkButton"+($fittedSet[0][0]).to_s
    @builder[checkButton].active = true
    if !($clicked.include? $fittedSet[0][0]) then 
       $clicked.push $fittedSet[0][0]
    end
  end 
end
# this method defines the operation for start button
# it create all 81 cards and print the 12 cards on the board, also it set the score to 0
def button3__clicked(*args)
      $score = 0
      @builder["entry1"].text = "Find Sets"
      @builder["entry2"].text = "Score: " + $score.to_s
      @builder["accuracy"].label = "N/A"
      @builder["button3"].label = "Restart"
      allCards = Range.new(0,80).to_a.shuffle
      $allCards = changeNumber allCards
      index = 12
      cards = $allCards[0, index]
      i = 1
      fitSet =[]
      fitSet, m = findSet cards   
      while m == 0 do 
        index = index +3
        cards = $allCards[0, index]
        fitSet, m = findSet cards
      end
      $currentSet = cards
      $fittedSet = fitSet
      $Index = index
      while i <= 15 do
           picName = "pic"+ i.to_s     
           if i<=cards.size then 
                @builder[picName].file = @path + cards[i-1].to_s
           else   
                @builder[picName].file = @path + "blank.png"
           end        
            i=i+1
      end
        j = 1
    while j <= 15 do
       button = "checkButton"+j.to_s
       @builder[button].active = false
       j = j+1
     end
end

#this methods record the signal from checkButton1
def checkButton1__clicked(*args)
  if $clicked.include? 1
    $clicked.delete 1
  else
    $clicked.push 1
  end
end
#this methods record the signal from checkButton2
def checkButton2__clicked(*args)
  if $clicked.include? 2
    $clicked.delete 2
  else
    $clicked.push 2
  end
end
#this methods record the signal from checkButton3
def checkButton3__clicked(*args)
  if $clicked.include? 3
    $clicked.delete 3
  else
    $clicked.push 3
  end
end
#this methods record the signal from checkButton4
def checkButton4__clicked(*args)
  if $clicked.include? 4
    $clicked.delete 4
  else
    $clicked.push 4
  end
end
#this methods record the signal from checkButton5
def checkButton5__clicked(*args)
  if $clicked.include? 5
    $clicked.delete 5
  else
    $clicked.push 5
  end
end
#this methods record the signal from checkButton6
def checkButton6__clicked(*args)
  if $clicked.include? 6
    $clicked.delete 6
  else
    $clicked.push 6
  end
end
#this methods record the signal from checkButton7
def checkButton7__clicked(*args)
  if $clicked.include? 7
    $clicked.delete 7
  else
    $clicked.push 7
  end
end
#this methods record the signal from checkButton8
def checkButton8__clicked(*args)
  if $clicked.include? 8
    $clicked.delete 8
  else
    $clicked.push 8
  end
end
#this methods record the signal from checkButton9
def checkButton9__clicked(*args)
  if $clicked.include? 9
    $clicked.delete 9
  else
    $clicked.push 9
  end
end
#this methods record the signal from checkButton10
def checkButton10__clicked(*args)
  if $clicked.include? 10
    $clicked.delete 10
  else
    $clicked.push 10
  end
end
#this methods record the signal from checkButton11
def checkButton11__clicked(*args)
  if $clicked.include? 11
    $clicked.delete 11
  else
    $clicked.push 11
  end
end
#this methods record the signal from checkButton12
def checkButton12__clicked(*args)
  if $clicked.include? 12
    $clicked.delete 12
  else
    $clicked.push 12
  end
end
#this methods record the signal from checkButton13
def checkButton13__clicked(*args)
  if $clicked.include? 13
    $clicked.delete 13
  else
    $clicked.push 13
  end
end
#this methods record the signal from checkButton14
def checkButton14__clicked(*args)
  if $clicked.include? 14
    $clicked.delete 14
  else
    $clicked.push 14
  end
end
#this methods record the signal from checkButton15
def checkButton15__clicked(*args)
  
  if $clicked.include? 15
    $clicked.delete 15
  else
    $clicked.push 15
  end
end
end

