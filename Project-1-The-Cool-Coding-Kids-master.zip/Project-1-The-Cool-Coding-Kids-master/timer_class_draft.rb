=begin
This is a draft of the Stopwatch class for Project 1.
This class will implement a timer that runs until all sets are found;
it then outputs the time to find all sets to the console.
=end
require 'time'

class Stopwatch
	$finish = Time.now
	def end_time(user_time)
		$finish = Time.now + user_time*60
	end
	def time_remaining
		remaining = $finish - Time.now
	end
end

puts "Would you like a stopwatch for your game? (Enter Yes/No): "
want_stopwatch = gets.to_s
want_stopwatch = want_stopwatch.chomp
want_stopwatch = want_stopwatch.upcase
#puts want_stopwatch
while ((want_stopwatch != "YES") and (want_stopwatch != "NO"))
		puts "Invalid input. Please enter Yes for a stopwatch or No for no stopwatch: "
		want_stopwatch = gets.to_s
		want_stopwatch = want_stopwatch.chomp
		want_stopwatch = want_stopwatch.upcase
end
if want_stopwatch == "YES"
	puts "Enter time for stopwatch (in minutes): "
	user_time = gets.to_i
	while (user_time < 1)
		puts "Time must be greater than 0. Enter a new time: "
		user_time = gets.to_i
	end
	timer = Stopwatch.new
	end_time = timer.end_time(user_time)
	while (Time.now < end_time)
		time_int = timer.time_remaining
		time_int = time_int.to_i
		time_int = time_int.round
		if (time_int%60 == 0) or (time_int%30 == 0)
			puts "#{time_int} seconds left!"
		end
		#puts time_int
		sleep 1
	end
	puts "No Time Remaining"
	elsif want_stopwatch == "NO"
			puts "No stopwatch needed"
	end



	

					
